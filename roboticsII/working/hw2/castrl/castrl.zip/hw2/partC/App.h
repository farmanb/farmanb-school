#include "AppGL.h"
class BallController;
class GripControl;
class PalmControl;

class App : public DVC_AppGL{
 public:
  App();
  ~App();
  
  bool Init();
  void PostStep();

 private:
  bool GetBodies();
  bool AddControllers();
  //void GoToPartCG();
  bool SetGripTorques(DVC::REAL torques[4]);
  void SetPalmVelocity(DVC::REAL x,DVC::REAL y, DVC::REAL rot);
  const DVC::Vector<DVC::REAL>& GetPalmPos();
  PalmControl *palmController;

  DVC::REAL m_torques[4];

  std::string **gripName,
    **partName, *palmName,
    *ballName;

  DynamicalBody **part, **grip,
     *ball;
  KinematicalBody *palm;
  GripControl **gripController;
  BallController *ballController;
  bool shot;
  int state;

};
